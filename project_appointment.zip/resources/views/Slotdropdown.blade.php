@foreach($avaliable_slot as $slot)

    <option value="{{ $slot }}"> {{ $slot }}</option>
@endforeach
