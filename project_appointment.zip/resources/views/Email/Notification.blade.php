<!DOCTYPE html>
<html>
<head>
    <title>Appointment Notification</title>
</head>
<body>
<h1>Hello, {{ $patient->name }}</h1>
<p>{{ $message }}</p>

<p>Thank you for using our service!</p>
</body>
</html>
