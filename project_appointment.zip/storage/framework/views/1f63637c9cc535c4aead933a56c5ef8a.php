<?php echo e($slot); ?>

<?php /**PATH G:\chiron\project_appointment\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>