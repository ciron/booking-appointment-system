<?php echo e($slot); ?>

<?php /**PATH G:\chiron\project_appointment\backend\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>