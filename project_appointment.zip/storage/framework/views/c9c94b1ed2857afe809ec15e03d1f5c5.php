<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('css'); ?>

    <?php $__env->stopPush(); ?>
<main>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Upcoming Appointment</li>
        </ol>

        <div class="row">

            <div class="card-body">
                <table id="datatablesSimple" class="table-responsive table ">
                    <thead>
                    <tr>
                        <th>Patient Name</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>

                        <th>Action</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($appointment->patient->name); ?></td>
                        <td><?php echo e($appointment->appointment_date); ?></td>
                        <td><?php echo e($appointment->timeslot); ?></td>
                        <td><?php echo e($appointment->status); ?></td>
                        <td>
                        <?php if($appointment->status == 'Pending'): ?>
                            <!-- Button to confirm appointment -->
                                <form action="<?php echo e(route('confirmAppointment', $appointment->id)); ?>" method="POST" style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-success">Confirm</button>
                                </form>
                                <!-- Button to cancel appointment -->
                                <form action="<?php echo e(route('cancelAppointment', $appointment->id)); ?>" method="POST" style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-danger">Cancel</button>
                                </form>
                        <?php elseif($appointment->status == 'Confirmed'): ?>
                            <!-- Button to cancel appointment -->
                                <form action="<?php echo e(route('cancelAppointment', $appointment->id)); ?>" method="POST" style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-danger">Cancel</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</main>
    <?php $__env->startPush('js'); ?>

    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.Master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\chiron\project_appointment\backend\resources\views/UpcomingAppoinment.blade.php ENDPATH**/ ?>