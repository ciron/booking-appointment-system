<!DOCTYPE html>
<html>
<head>
    <title>Appointment Notification</title>
</head>
<body>
<h1>Hello, <?php echo e($patient->name); ?></h1>
<p><?php echo e($message); ?></p>

<p>Thank you for using our service!</p>
</body>
</html>
<?php /**PATH G:\chiron\project_appointment\backend\resources\views/Email/Notification.blade.php ENDPATH**/ ?>