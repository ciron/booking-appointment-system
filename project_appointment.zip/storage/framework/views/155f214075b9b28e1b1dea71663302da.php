<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH G:\chiron\project_appointment\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>