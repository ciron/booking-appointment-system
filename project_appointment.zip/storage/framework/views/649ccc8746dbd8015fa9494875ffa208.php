<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH G:\chiron\project_appointment\backend\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>