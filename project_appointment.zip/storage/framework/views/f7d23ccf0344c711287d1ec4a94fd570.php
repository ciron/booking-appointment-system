<?php $__currentLoopData = $avaliable_slot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <option value="<?php echo e($slot); ?>"> <?php echo e($slot); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH G:\chiron\project_appointment\backend\resources\views/Slotdropdown.blade.php ENDPATH**/ ?>