<?php echo e($slot); ?>

<?php /**PATH G:\chiron\project_appointment\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>